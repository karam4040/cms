$(document).ready(function () {
	"use strict";

}) ;